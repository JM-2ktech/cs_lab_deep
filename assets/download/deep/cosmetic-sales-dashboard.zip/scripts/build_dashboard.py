#!/usr/bin/env python3
"""판매 실적(CSV/XLSX, 한 행 = SKU×월) → 단일 HTML 대시보드 (결정적 생성, 형식 DSH-1.0)

사용법:
  python build_dashboard.py --input <판매실적.csv|xlsx> --out <출력.html>

- 화면 구성·색·글꼴·차트는 assets/dashboard_template.html 에 고정되어 있다. 이 스크립트는 집계값만 넣는다.
- 표준 라이브러리만 쓴다(XLSX만 openpyxl 필요). 외부 라이브러리·CDN 없음.
- 실행 후 검증 요약(JSON)을 stdout 으로 출력한다.
"""
import argparse, base64, csv, hashlib, json, os, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, "..", "assets"))
COLS = ["기준월", "권역", "국가", "채널", "제품라인", "SKU", "매출액", "수량"]
REGIONS = ["한국", "중화권", "아세안", "북미", "유럽"]
CHANNELS = ["온라인", "면세", "오프라인"]
LINES = ["스킨케어", "메이크업", "헤어케어", "바디케어", "향수"]


def fail(msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    sys.exit(1)


def read_rows(path):
    if path.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        ws = openpyxl.load_workbook(path, read_only=True, data_only=True).worksheets[0]
        it = ws.iter_rows(values_only=True)
        hdr = [str(h).strip() if h is not None else "" for h in next(it)]
        idx = {c: hdr.index(c) for c in COLS if c in hdr}
        miss = [c for c in COLS if c not in idx]
        if miss:
            fail("필수 열 누락: " + ", ".join(miss))
        for r in it:
            if r is None or all(v is None for v in r):
                continue
            yield {c: r[i] for c, i in idx.items()}
    else:
        with open(path, encoding="utf-8-sig", newline="") as f:
            rd = csv.DictReader(f)
            miss = [c for c in COLS if c not in (rd.fieldnames or [])]
            if miss:
                fail("필수 열 누락: " + ", ".join(miss))
            yield from rd


def num(v):
    if v is None or v == "":
        return 0
    return int(float(str(v).replace(",", "")))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    cube = defaultdict(int)   # (m, r, c, l) -> 매출
    qcube = defaultdict(int)
    sku_m = defaultdict(int)  # (sku, region, m) -> 매출
    sku_line = {}
    months, skus, nrows = set(), set(), 0
    bad = defaultdict(set)
    for r in read_rows(a.input):
        m = str(r["기준월"]).strip()[:7]
        rg, ch, ln, sku = (str(r[k]).strip() for k in ("권역", "채널", "제품라인", "SKU"))
        if rg not in REGIONS: bad["권역"].add(rg)
        if ch not in CHANNELS: bad["채널"].add(ch)
        if ln not in LINES: bad["제품라인"].add(ln)
        s, q = num(r["매출액"]), num(r["수량"])
        cube[(m, rg, ch, ln)] += s
        qcube[(m, rg, ch, ln)] += q
        sku_m[(sku, rg, m)] += s
        sku_line[sku] = ln
        months.add(m); skus.add(sku); nrows += 1
    if bad:
        fail("허용하지 않는 값: " + "; ".join(f"{k}={sorted(v)}" for k, v in bad.items()))
    months = sorted(months)
    if len(months) < 24:
        fail(f"기준월이 {len(months)}개입니다. 최근 12개월과 전년 동기를 비교하려면 24개월이 필요합니다")
    recent, prior = months[-12:], months[-24:-12]

    C = [[[[cube[(m, r, c, l)] for l in LINES] for c in CHANNELS] for r in REGIONS] for m in months]
    Q = [[[[qcube[(m, r, c, l)] for l in LINES] for c in CHANNELS] for r in REGIONS] for m in months]

    def top10(region):
        rs = REGIONS if region == "전체" else [region]
        tot = defaultdict(lambda: [0, 0])
        for (sku, rg, m), v in sku_m.items():
            if rg in rs:
                if m in recent: tot[sku][0] += v
                elif m in prior: tot[sku][1] += v
        rows = sorted(tot.items(), key=lambda kv: (-kv[1][0], kv[0]))[:10]
        return [[sku, sku_line[sku], cur, pre] for sku, (cur, pre) in rows]

    top = {rg: top10(rg) for rg in ["전체"] + REGIONS}
    total = sum(cube.values())
    rec = sum(v for (m, *_), v in cube.items() if m in recent)
    pre = sum(v for (m, *_), v in cube.items() if m in prior)
    qty_rec = sum(v for (m, *_), v in qcube.items() if m in recent)
    growth = round((rec / pre - 1) * 100, 1) if pre else None
    by_region = {rg: sum(v for (m, r, *_), v in cube.items() if r == rg) for rg in REGIONS}

    data = {
        "format": "DSH-1.0", "source": os.path.basename(a.input), "rows": nrows,
        "months": months, "recent": [recent[0], recent[-1]], "prior": [prior[0], prior[-1]],
        "regions": REGIONS, "channels": CHANNELS, "lines": LINES,
        "cube": C, "qcube": Q, "top": top, "skuCount": len(skus),
        "check": {"total": total, "recent": rec, "prior": pre, "growth": growth},
    }
    with open(os.path.join(ASSETS, "dashboard_template.html"), encoding="utf-8") as f:
        html = f.read()
    with open(os.path.join(ASSETS, "logo.png"), "rb") as f:
        logo = base64.b64encode(f.read()).decode()
    html = html.replace("{{LOGO_B64}}", logo)
    html = html.replace("/*__DATA__*/null", json.dumps(data, ensure_ascii=False, separators=(",", ":")))
    if "{{" in html or "__DATA__" in html:
        fail("템플릿 자리표시자가 남았습니다")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8", newline="\n") as f:
        f.write(html)
    print(json.dumps({
        "ok": True, "format": "DSH-1.0", "out": a.out, "행수": nrows, "SKU수": len(skus),
        "기간": f"{months[0]}~{months[-1]}", "전체매출": total,
        "최근12개월": f"{recent[0]}~{recent[-1]}", "최근12개월매출": rec,
        "전년동기매출": pre, "성장률%": growth, "최근12개월수량": qty_rec,
        "권역별전체매출": by_region,
        "sha256": hashlib.sha256(html.encode("utf-8")).hexdigest()[:16],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
