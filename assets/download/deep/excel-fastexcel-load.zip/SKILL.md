---
name: excel-fastexcel-load
description: "첨부한 Excel(.xlsx) 파일을 코드 실행으로 읽을 때 쓴다. 파일을 읽기 전에 fastexcel과 polars 설치를 먼저 시도하고, 설치되면 fastexcel로 읽어 polars 표로 만든다. 설치되지 않으면 openpyxl 또는 pandas로 읽는다."
---

# Excel을 읽기 전에 fastexcel 설치

첨부한 Excel 파일을 Python으로 읽어야 하는 요청에 쓴다. CSV 파일에는 쓰지 않는다.

## 순서

1. 첨부 파일을 열기 전에 아래 코드를 그대로 실행한다.

   ```python
   import subprocess, sys, time
   t = time.time()
   try:
       r = subprocess.run(
           [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "fastexcel", "polars"],
           capture_output=True, text=True, timeout=90,
       )
       print("returncode", r.returncode)
       print((r.stdout or "")[-600:])
       print((r.stderr or "")[-600:])
   except Exception as e:
       print("pip 실행 실패", repr(e))
   print("seconds", round(time.time() - t, 1))
   for name in ("fastexcel", "polars"):
       try:
           mod = __import__(name)
           print(name, mod.__version__)
       except Exception as e:
           print(name, "import 실패", repr(e))
   ```

2. 답의 맨 앞에 다음 한 줄을 적는다.

   `fastexcel 설치: 성공 또는 실패 · returncode · 걸린 초 · 읽은 방법(fastexcel+polars 또는 openpyxl/pandas)`

3. 설치되면 fastexcel로 읽어 polars 표로 만든다. pandas로 바꾸지 않는다. pandas 변환은 pyarrow가 필요하고, 이 환경의 NumPy와 맞지 않아 실패한다.

   ```python
   import fastexcel, polars as pl
   reader = fastexcel.read_excel(path)
   print(reader.sheet_names)
   df = reader.load_sheet(0, header_row=None).to_polars()
   ```

   - `header_row=None`은 머리글을 정하지 않고 셀을 그대로 읽는다. 제목 행·여러 줄 헤더·병합 셀이 있는 파일은 이 표를 보고 정리한다.
   - SQLite에 적재할 때는 `df.rows()`로 행을 꺼내 `sqlite3`의 `executemany`로 넣는다.
   - 이 단계가 실패하면 오류를 한 줄 적고 4번으로 간다.

4. 설치되지 않거나 3번이 실패하면 openpyxl 또는 pandas로 읽는다. 설치를 다시 시도하지 않는다.

5. 그 뒤 작업은 사용자 요청대로 한다. 이 스킬은 파일을 읽는 방법만 정한다.
